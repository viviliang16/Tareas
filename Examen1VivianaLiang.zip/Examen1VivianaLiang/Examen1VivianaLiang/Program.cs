﻿using System;

namespace Examen1VivianaLiang
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.principal();
        }
    }
}
