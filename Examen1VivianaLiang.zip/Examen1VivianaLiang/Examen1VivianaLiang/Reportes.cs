﻿////using System;
////using System.Collections.Generic;
////using System.Text;

////namespace Examen1VivianaLiang
////{
////    class Reportes
////    {
////        static Servicios s= new Servicios();
////        string[] valor = s.Realizar_Pagos();
////       
////    }
////}



//for (int i = 0; i < números_pagos.Length; i++)
//{
//    if (opcion == 1) //DEBE SALIR UN RECORRIDO DE SOLO DEL SERVICIO DE TIPO DE ELECTRICIDAD
//    {

//        Console.WriteLine($" {números_pagos[i]}     {cedula[i]}     {nombre[i]}     {apellido1[i]}  {apellido2[i]}  {numero}    ");
//        Console.WriteLine($" {nfactura[i]}  {monto_a_pagar[i]}   {ts[i]}  {comision[i]} {deducido[i]} {vuelto[i]} {pago_total[i]}");
//        Console.WriteLine("============================================================================================================================================================================================");
//        Console.WriteLine("                                         <PULSE CUALQUIER TECLA PARA ABANDONAR>      ");


//    }

//    else if (opcion == 2) //DEBE SALIR UN RECORRIDO DE SOLO DEL SERVICIO DE TIPO TELEFONO
//    {
//        Console.WriteLine($" {números_pagos[i]}     {cedula[i]}     {nombre[i]}     {apellido1[i]}  {apellido2[i]}   {numero}    ");
//        Console.WriteLine($" {nfactura[i]}    {monto_a_pagar[i]}      {ts[i]}        {comision[i]}     {deducido[i]}   {vuelto[i]}   {pago_total[i]}");
//        Console.WriteLine("============================================================================================================================================================================================");
//        Console.WriteLine("                                         <PULSE CUALQUIER TECLA PARA ABANDONAR>      ");
//    }

//    else if (opcion == 3) //DEBE SALIR UN RECORRIDO DE SOLO DEL SERVICIO DE TIPO AGUA 
//    {
//        Console.WriteLine($" {fecha} {tiempo} {números_pagos[i]}     {cedula[i]}     {nombre[i]}     {apellido1[i]}  {apellido2[i]} {numero}    ");
//        Console.WriteLine($" {nfactura[i]}    {monto_a_pagar[i]}      {ts[i]}        {comision[i]}     {deducido[i]}   {vuelto[i]}   {pago_total[i]}");
//        Console.WriteLine("============================================================================================================================================================================================");
//        Console.WriteLine("                                         <PULSE CUALQUIER TECLA PARA ABANDONAR>      ");
//    }
