﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea2_Menu_Submenus_
{
    class Program
    {
        static void Main(string[] args)
        {

            Menu.principal();
        
        }

    }
}
